import React from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import MovieSearch from './components/MovieSearch';
import AboutDeveloper from './components/AboutDeveloper';


const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#5c6bc0',
    },
    secondary: {
      main: '#ab47bc',
    },
    background: {
      default: '#1a1a2e',
      paper: '#D5006D',
    },
    text: {
      primary: '#ffffff',
      secondary: '#e0e0e0',
    },
  },
});

const App = () => {
  return (
    <ThemeProvider theme={theme}>
      <div style={{ padding: '50px' }}>
        <MovieSearch />
        <AboutDeveloper />
      </div>
    </ThemeProvider>
  );
};

export default App;
import React from 'react';
import { Typography, Paper, Box, Avatar } from '@mui/material';

const AboutDeveloper = () => {
  return (
    <Paper elevation={3} sx={{ padding: 3, marginTop: 4, bgcolor: 'background.paper' }}>
      <Box sx={{ textAlign: 'center' }}>
        <Typography variant="h4" gutterBottom>ABOUT THE DEVELOPER</Typography>
        <Avatar 
          img="./pic-removebg-preview.png"
          alt="Aira Marie Bautista" 
          sx={{ width: 150, height: 150, margin: 'auto', border: '2px solid #9c27b0' }} 
        />
        
        <Typography variant="h6" sx={{ marginTop: 2 }}>AIRA MARIE BAUTISTA</Typography>
        
        <Typography variant="body1" sx={{ marginBottom: 2, marginTop: 2 }}>
        Aira Marie Bautista is a creative individual who loves exploring new ideas and expressing herself through art and design. She enjoy collaborating with others to bring projects to life.
        </Typography>
        <Typography variant="body1">
        Connect with Aira on social media to follow her journey and collaborate on exciting projects!
        </Typography>
      </Box>
    </Paper>
  );
};

export default AboutDeveloper;

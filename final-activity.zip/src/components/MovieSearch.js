import React, { useState } from 'react';
import {
  TextField,
  Select,
  MenuItem,
  Button,
  CircularProgress,
  Typography,
  Box,
  Paper,
  Autocomplete,
  Grid,
} from '@mui/material';
import axios from 'axios';
import '../css/styles.css';

const MovieSearch = () => {
  const [title, setTitle] = useState('');
  const [year, setYear] = useState('');
  const [plot, setPlot] = useState('');
  const [loading, setLoading] = useState(false);
  const [movie, setMovie] = useState(null);
  const [error, setError] = useState('');
  const [options, setOptions] = useState([]);

  const handleSearch = async () => {
    setLoading(true);
    setError('');
    setMovie(null);

    try {
      const response = await axios.get(
        `https://www.omdbapi.com/?t=${encodeURIComponent(title)}&y=${year}&plot=${plot}&apikey=489caf77`
      );
      if (response.data.Response === "True") {
        setMovie(response.data);
      } else {
        setError(response.data.Error);
      }
    } catch (err) {
      setError("Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  const handleTitleChange = async (event, value) => {
    setTitle(value);
    if (value) {
      try {
        const response = await axios.get(
          `https://www.omdbapi.com/?s=${encodeURIComponent(value)}&apikey=489caf77`
        );
        setOptions(response.data.Search ? response.data.Search.map(movie => movie.Title) : []);
      } catch (err) {
        console.error("Error fetching suggestions:", err);
      }
    } else {
      setOptions([]);
    }
  };

  return (
    <Paper elevation={3} sx={{ padding: 3, marginBottom: 3 }}>
      <Typography variant="h5" align="center" gutterBottom>
        Movie Search
      </Typography>
      <Grid container spacing={2} alignItems="center">
        <Grid item xs={12} sm={6}>
          <Autocomplete
            freeSolo
            options={options}
            onInputChange={handleTitleChange}
            renderInput={(params) => (
              <TextField {...params} label="Title" variant="outlined" fullWidth />
            )}
          />
        </Grid>
        <Grid item xs={12} sm={3}>
          <TextField
            label="Year"
            variant="outlined"
            fullWidth
            value={year}
            onChange={(e) => setYear(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={2}>
          <Select
            label="Plot"
            variant="outlined"
            fullWidth
            value={plot}
            onChange={(e) => setPlot(e.target.value)}
            displayEmpty
          >
            <MenuItem value="">
              <em>Select Plot</em>
            </MenuItem>
            <MenuItem value="short">Short</MenuItem>
            <MenuItem value="full">Full</MenuItem>
          </Select>
        </Grid>
        <Grid item xs={12} sm={1}>
          <Button
            variant="contained"
            onClick={handleSearch}
            fullWidth
            sx={{ bgcolor: 'secondary.main' }}
          >
            Search
          </Button>
        </Grid>
      </Grid>

      {loading && <CircularProgress sx={{ display: 'block', margin: '0 auto', marginTop: 2 }} />}
      {error && <Typography color="error" align="center" sx={{ marginTop: 2 }}>{error}</Typography>}
      
      {movie && (
        <Box sx={{ marginTop: 2, textAlign: 'center' }}>
          <Typography variant="h6">{movie.Title} ({movie.Year})</Typography>
          <img src={movie.Poster} alt={movie.Title} style={{ maxWidth: '100%', marginBottom: 10 }} />
          <Typography variant="body1">{movie.Plot}</Typography>
        </Box>
      )}
    </Paper>
  );
};

export default MovieSearch;
